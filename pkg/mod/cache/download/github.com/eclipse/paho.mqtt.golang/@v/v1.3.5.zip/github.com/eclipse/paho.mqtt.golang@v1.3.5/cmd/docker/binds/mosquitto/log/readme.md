log
===

If you enable logging to a file in the `mosquitto.conf` then the logs will be written here